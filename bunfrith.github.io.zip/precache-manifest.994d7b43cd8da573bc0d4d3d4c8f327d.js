self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7c6965b017544ed592a9",
    "url": "/css/app.27301b2b.css"
  },
  {
    "revision": "9606b303875c0855dc2b",
    "url": "/css/chunk-05b4bfb0.f06bc180.css"
  },
  {
    "revision": "f4685f10df57cd9c506f",
    "url": "/css/chunk-5ad1e1c2.dfb522e0.css"
  },
  {
    "revision": "5f9d3b616b1db460c425",
    "url": "/css/chunk-9587d44e.d7549f93.css"
  },
  {
    "revision": "12104dced9025eee9c1d",
    "url": "/css/chunk-e8440718.4a352d0e.css"
  },
  {
    "revision": "31ab25be5ccc9e8ba2a0",
    "url": "/css/chunk-vendors.8fe7522e.css"
  },
  {
    "revision": "322b87cc74acf1f88fcc7c6b7393b5eb",
    "url": "/img/dislike.322b87cc.svg"
  },
  {
    "revision": "1911fea2d91b4f61d2844c714345c946",
    "url": "/img/fullscreen.1911fea2.svg"
  },
  {
    "revision": "97a52ca9023f6b29f4e034b864e30360",
    "url": "/img/game-bg.97a52ca9.jpg"
  },
  {
    "revision": "755d10203e08607fcc4d372e0ef566d4",
    "url": "/img/game-item.755d1020.png"
  },
  {
    "revision": "7b805f39c0ec25880ad3433659faa678",
    "url": "/img/like-small.7b805f39.svg"
  },
  {
    "revision": "e9a98a1d29cdcd9e0f0d1b14c10032ca",
    "url": "/img/like.e9a98a1d.svg"
  },
  {
    "revision": "617d137601e96549edfd79a6a933d58f",
    "url": "/img/logo-small.617d1376.png"
  },
  {
    "revision": "8a97778ebc041a9281631086e70b46b1",
    "url": "/img/logo.8a97778e.svg"
  },
  {
    "revision": "6cbfbc09374208085fd0bb55379f3845",
    "url": "/img/pwa-icon.6cbfbc09.svg"
  },
  {
    "revision": "d7a38a589317c80d770d699b19f5d819",
    "url": "/img/search.d7a38a58.svg"
  },
  {
    "revision": "cb172235d3e2f90edaa01757a615c4c3",
    "url": "/img/small-pwa.cb172235.svg"
  },
  {
    "revision": "749c41c8b0591a80acce35a0da7f59dd",
    "url": "/img/star-small.749c41c8.svg"
  },
  {
    "revision": "8fff700f66dc566c4063423cbc4d73da",
    "url": "/img/star.8fff700f.svg"
  },
  {
    "revision": "f1451b0ad94eadf09d69833f19524596",
    "url": "/img/up-btn.f1451b0a.svg"
  },
  {
    "revision": "dca7c226a99cbb79521ef58eea688cc2",
    "url": "/index.html"
  },
  {
    "revision": "7c6965b017544ed592a9",
    "url": "/js/app.1c46274a.js"
  },
  {
    "revision": "9606b303875c0855dc2b",
    "url": "/js/chunk-05b4bfb0.7791730d.js"
  },
  {
    "revision": "3a3e50cb85bf613218e7",
    "url": "/js/chunk-2d0da793.cd38fad9.js"
  },
  {
    "revision": "f4685f10df57cd9c506f",
    "url": "/js/chunk-5ad1e1c2.3962137d.js"
  },
  {
    "revision": "5f9d3b616b1db460c425",
    "url": "/js/chunk-9587d44e.16deb5db.js"
  },
  {
    "revision": "12104dced9025eee9c1d",
    "url": "/js/chunk-e8440718.211d4232.js"
  },
  {
    "revision": "31ab25be5ccc9e8ba2a0",
    "url": "/js/chunk-vendors.fb2f471d.js"
  },
  {
    "revision": "922366607c5a3cda943e30df1a1b8abd",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "228517a125d5370a7d3966717c49808a",
    "url": "/yayoye-icon.ico"
  }
]);